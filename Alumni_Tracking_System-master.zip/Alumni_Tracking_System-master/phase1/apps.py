from django.apps import AppConfig


class Phase1Config(AppConfig):
    name = 'phase1'

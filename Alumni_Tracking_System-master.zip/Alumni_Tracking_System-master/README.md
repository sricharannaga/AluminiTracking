# Alumni_Tracking_System
source code for website named Alumni Tracking System is included in this.

Alumni Tracking System - is a Website developed for giving a provision to Alumni of an Institution to merge their profile in a 
central platform and update if necessary.And also provision for Instituions to View their Alumni .

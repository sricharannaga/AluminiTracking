from django.apps import AppConfig


class Phase2Config(AppConfig):
    name = 'phase2'
